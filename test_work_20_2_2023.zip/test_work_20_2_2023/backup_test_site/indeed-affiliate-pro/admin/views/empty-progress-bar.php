<div class="progress-bar-parent">
    <div class="uap-progress">
      <div class="uap-progress-bar-warning"><?php esc_html_e("Do not refresh or leave this page until the process it's over!", 'uap');?></div>
      <div class="progress-bar progress-bar-nowidth" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
      </div>
    </div>
</div>
