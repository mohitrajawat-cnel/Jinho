<div class="uap-error-global-dashboard-message uap-admin-dashboard-notice-mk-message">
    <div class='uap-close-notice uap-js-close-admin-dashboard-mk-notice' data-name="mycred">x</div>
    <p>
      <?php echo esc_html__( "Incorporate the reward system of MyCred with Ultimate Affiliate Pro. Check this out: ", 'uap' );?>
      <a href="https://store.wpindeed.com/addon/mycred-integration/" target="_blank">Ultimate Affiliate Pro - MyCRED Integration</a>
    </p>
</div>
